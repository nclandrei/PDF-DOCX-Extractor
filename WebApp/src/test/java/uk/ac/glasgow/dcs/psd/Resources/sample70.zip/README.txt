You will find 2 folders named "csv" and "images".

The "csv" folder will contain all the tables extracted from the PDF/DOCX you provided, while the "images" one will have all images (JPG and PNG formats) found inside the file.

Thank you for using our application!

Crichton Institute - Regional Observatory

Developers:
Ian Denev
Ivan Kyosev
Andrei-Mihai Nicolae
Richard Pearson
Edvinas Simkus